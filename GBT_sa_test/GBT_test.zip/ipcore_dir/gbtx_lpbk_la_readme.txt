The following files were generated for 'gbtx_lpbk_la' in directory
C:\ISE_core_gen\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * gbtx_lpbk_la.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * gbtx_lpbk_la.cdc
   * gbtx_lpbk_la.constraints/gbtx_lpbk_la.ucf
   * gbtx_lpbk_la.constraints/gbtx_lpbk_la.xdc
   * gbtx_lpbk_la.ncf
   * gbtx_lpbk_la.ngc
   * gbtx_lpbk_la.ucf
   * gbtx_lpbk_la.v
   * gbtx_lpbk_la.veo
   * gbtx_lpbk_la.xdc
   * gbtx_lpbk_la_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * gbtx_lpbk_la.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * gbtx_lpbk_la.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * gbtx_lpbk_la.gise
   * gbtx_lpbk_la.xise

Deliver Readme:
   Readme file for the IP.

   * gbtx_lpbk_la_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * gbtx_lpbk_la_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

